#pragma once


void empty_function(){}