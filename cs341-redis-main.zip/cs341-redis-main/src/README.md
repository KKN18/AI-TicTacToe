# Redis Skeleton

- `redis-cli.cpp`: Redis client (submit this)
- `redis-server.cpp`: Redis server (submit this)
- `common.hpp`: common header for server & client (submit this)
- `Makefile`: build script (do not submit)
- `Dockerfile`: docker script (do not submit)
