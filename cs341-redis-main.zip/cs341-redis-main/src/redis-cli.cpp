#include <cstdio>
#include "common.hpp"

int main(int argc, char *argv[])
{
    printf("Hello World\n");
    return 0;
}
